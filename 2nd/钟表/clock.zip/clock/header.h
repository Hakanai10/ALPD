#pragma once
void init();
void ticktock(int new_hour, int new_minute, int new_second, int old_hour = -1, int old_minute = -1, int old_second = -1);
void AntiAliasingForCircle(int x0, int y0, int radius, int thickness, int fg_color, int bk_color);